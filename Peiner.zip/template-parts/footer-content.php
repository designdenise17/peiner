<footer class="u-align-center u-clearfix u-container-align-center u-container-align-center-lg u-container-align-center-xl u-footer" id="footer">
  <div class="u-clearfix u-sheet u-valign-top-md u-sheet-1">
    <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-1" src="<?php echo get_template_directory_uri(); ?>/images/engineered_germany.png" alt="" data-image-width="177" data-image-height="56">
    <p class="u-align-left u-small-text u-text u-text-grey-50 u-text-variant u-text-1">Impressum.&nbsp; Datenschutz.&nbsp; AGB.&nbsp; Cookie-Einstellungen.&nbsp; Kontakt</p>
  </div>
</footer>