<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
<style> .u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 123px;
}
.u-header .u-image-1 {
  width: 63px;
  height: 63px;
  margin: 41px auto 0 0;
}
.u-header .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
.u-header .u-text-1 {
  font-size: 1.875rem;
  margin: -63px 921px 0 82px;
}
.u-header .u-menu-1 {
  margin: -47px -1px 0 auto;
}
.u-header .u-hamburger-link-1 {
  font-size: 1rem;
  padding: 4px 1px;
}
.u-header .u-nav-1 {
  font-weight: 500;
  font-size: 1rem;
  text-transform: none;
}
.u-block-75b9-39 {
  font-size: 1rem;
}
.u-header .u-nav-2 {
  font-size: 1rem;
}
.u-block-75b9-41 {
  font-size: 1rem;
}
.u-header .u-line-1 {
  transform-origin: right center;
  width: 2466px;
  margin: 19px -663px 6px;
}
@media (max-width: 1199px) {
  .u-header .u-sheet-1 {
    min-height: 124px;
  }
  .u-header .u-text-1 {
    width: auto;
    margin-right: 720px;
    margin-left: 83px;
  }
  .u-header .u-menu-1 {
    margin-top: -47px;
    margin-right: -1px;
  }
  .u-header .u-line-1 {
    transform-origin: left center;
    width: 2744px;
    margin: 25px 0 0 -940px;
  }
}
@media (max-width: 991px) {
  .u-header .u-text-1 {
    margin-top: -66px;
    margin-right: 500px;
  }
  .u-header .u-menu-1 {
    width: auto;
    margin-top: -24px;
  }
  .u-header .u-line-1 {
    transform-origin: right center;
    width: 2457px;
    margin-top: 20px;
    margin-left: -1005px;
  }
}
@media (max-width: 767px) {
  .u-header .u-text-1 {
    margin-right: 326px;
    margin-left: 77px;
  }
  .u-header .u-menu-1 {
    margin-top: -24px;
  }
  .u-header .u-line-1 {
    width: 2751px;
    margin-left: -1054px;
  }
}
@media (max-width: 575px) {
  .u-header .u-text-1 {
    margin-right: 126px;
  }
  .u-header .u-hamburger-link-1 {
    font-size: calc(1em + 8px);
  }
  .u-header .u-line-1 {
    width: 2359px;
    margin-left: -1034px;
  }
}</style>
