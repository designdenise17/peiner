<!-- footer styles -->

<style>.u-footer .u-sheet-1 {
  min-height: 156px;
}
.u-footer .u-image-1 {
  width: 177px;
  height: 56px;
  margin: 0 49px 0 auto;
}
.u-footer .u-text-1 {
  margin: -39px 723px 60px 0;
}
@media (max-width: 1199px) {
  .u-footer .u-text-1 {
    margin-top: -39px;
    margin-right: 523px;
  }
}
@media (max-width: 991px) {
  .u-footer .u-image-1 {
    margin-right: 0;
  }
  .u-footer .u-text-1 {
    margin-right: 303px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-sheet-1 {
    min-height: 256px;
  }
  .u-footer .u-image-1 {
    margin-top: 56px;
    margin-right: 4px;
  }
  .u-footer .u-text-1 {
    margin-top: -95px;
    margin-right: 123px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-image-1 {
    margin-right: 4px;
  }
  .u-footer .u-text-1 {
    width: auto;
    margin-top: -95px;
    margin-right: 0;
  }
}</style>
